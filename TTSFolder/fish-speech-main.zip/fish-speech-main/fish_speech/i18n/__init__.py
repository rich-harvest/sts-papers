from .core import i18n

__all__ = ["i18n"]
