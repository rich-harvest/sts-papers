## Simple Notebook to Analyze a Dataset

By the use of this notebook, you can easily analyze a brand new dataset, find exceptional cases and define your training set.

What we are looking in here is reasonable distribution of instances in terms of sequence-length, audio-length and word-coverage. 

This notebook is inspired from https://github.com/MycroftAI/mimic2
